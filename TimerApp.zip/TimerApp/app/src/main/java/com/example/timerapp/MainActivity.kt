package com.example.timerapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.timerapp.databinding.ActivityMainBinding
import java.security.KeyStore.TrustedCertificateEntry
import kotlin.concurrent.timer

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var isRunning = false
    private var timerSecs = 0

    private val handler = Handler(Looper.getMainLooper())
    private val runnable = object : Runnable{
        @SuppressLint("DefaultLocale")
        override fun run() {
            timerSecs++

            val hours = timerSecs / 3600
            val mins = (timerSecs % 3600)/60
            val secs  = timerSecs % 60

            val time = String.format("%02d:%02d:%02d",hours,mins,secs)
            binding.timer.text = time

            handler.postDelayed(this,1000)

        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        enableEdgeToEdge()

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        binding.startBtn.setOnClickListener {
            startTime()
        }

        binding.stopBtn.setOnClickListener{
            stopTime()
        }

        binding.resetBtn.setOnClickListener{
            resetTimer()
        }

    }

    private fun startTime(){
        if(!isRunning){
            handler.postDelayed(runnable,1000)
            isRunning = true
            binding.startBtn.isEnabled = false
            binding.stopBtn.isEnabled = true
            binding.resetBtn.isEnabled = true
            binding.stopBtn.text = "Stop"
        }
        Toast.makeText(this, "Timer Started", Toast.LENGTH_SHORT).show()
    }



    private fun stopTime() {
        if (isRunning) {
            // Currently running, so pause the timer
            handler.removeCallbacks(runnable)
            isRunning = false

            binding.startBtn.isEnabled = true
            binding.resetBtn.isEnabled = true

            // Change stop button text to Continue
            binding.stopBtn.text = "Continue"

            Toast.makeText(this, "Timer Paused", Toast.LENGTH_SHORT).show()
        } else {
            // Timer is paused, so resume it
            handler.post(runnable)
            isRunning = true

            binding.startBtn.isEnabled = false

            // Change stop button text back to Stop
            binding.stopBtn.text = "Stop"

            Toast.makeText(this, "Timer Resumed", Toast.LENGTH_SHORT).show()
        }
    }


    private fun resetTimer(){
        stopTime()
        timerSecs = 0
        binding.timer.text = "00:00:00"
        binding.startBtn.isEnabled = true
        binding.resetBtn.isEnabled = true
        binding.startBtn.text = "Start"
        binding.stopBtn.text = "Stop"
        Toast.makeText(this, "Timer Reset", Toast.LENGTH_SHORT).show()
    }

}